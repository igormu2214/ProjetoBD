package com.projetoaeso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoaesoApplicationTests {

	@Test
	void contextLoads() {
	}

}
